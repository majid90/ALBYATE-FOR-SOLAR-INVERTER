ALBYATE v0.3.2 - Firebase compatibility build

تم تثبيت Android Gradle Plugin 8.11.1 و Kotlin 2.2.20 و Gradle 8.14.
تم تثبيت firebase-auth Android على 23.2.1 لتجنب مكتبة 25.0.0 ذات Kotlin metadata 2.4.0.
هذه حزمة مصدر جاهزة لتجربة GitHub Actions وليست APK مبنياً أو مضمون النجاح.

ارفع محتويات هذا ZIP بعد فك الضغط إلى جذر المستودع.
شغل workflow: Build ALBYATE APK - Fixed Firebase
تنبيه: إذا بقي workflow قديم، شغّل الاسم المذكور أعلاه تحديداً.
