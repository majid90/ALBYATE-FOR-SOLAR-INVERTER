import 'package:crypto/crypto.dart';
import 'dart:convert';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import 'package:uuid/uuid.dart';

class AppDb {
  AppDb._();
  static final AppDb instance = AppDb._();
  Database? _db;
  final _uuid = const Uuid();

  String newId() => _uuid.v4();
  String hashPassword(String value) => sha256.convert(utf8.encode(value)).toString();

  Future<Database> get database async {
    if (_db != null) return _db!;
    final base = await getDatabasesPath();
    _db = await openDatabase(
      p.join(base, 'albyate_center.db'),
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''CREATE TABLE centers (
          id TEXT PRIMARY KEY, name TEXT NOT NULL, owner_name TEXT NOT NULL,
          username TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL, created_at TEXT NOT NULL
        )''');
        await db.execute('''CREATE TABLE users (
          id TEXT PRIMARY KEY, center_id TEXT NOT NULL, name TEXT NOT NULL,
          username TEXT NOT NULL, password_hash TEXT NOT NULL, role TEXT NOT NULL,
          active INTEGER NOT NULL DEFAULT 1,
          UNIQUE(center_id, username)
        )''');
        await db.execute('''CREATE TABLE customers (
          id TEXT PRIMARY KEY, center_id TEXT NOT NULL, name TEXT NOT NULL,
          phone TEXT, notes TEXT, created_at TEXT NOT NULL
        )''');
        await db.execute('''CREATE TABLE devices (
          id TEXT PRIMARY KEY, center_id TEXT NOT NULL, serial TEXT NOT NULL,
          brand TEXT, model TEXT, power TEXT, customer_name TEXT, customer_phone TEXT,
          fault TEXT, status TEXT NOT NULL, label_photo TEXT, created_at TEXT NOT NULL,
          UNIQUE(center_id, serial)
        )''');
        await db.execute('''CREATE TABLE repairs (
          id TEXT PRIMARY KEY, center_id TEXT NOT NULL, device_id TEXT NOT NULL,
          technician TEXT, diagnosis TEXT, work_done TEXT, labor_cost REAL NOT NULL DEFAULT 0,
          parts_cost REAL NOT NULL DEFAULT 0, received_amount REAL NOT NULL DEFAULT 0,
          created_at TEXT NOT NULL
        )''');
        await db.execute('''CREATE TABLE parts (
          id TEXT PRIMARY KEY, center_id TEXT NOT NULL, name TEXT NOT NULL,
          sku TEXT, quantity INTEGER NOT NULL DEFAULT 0,
          purchase_price REAL NOT NULL DEFAULT 0, sale_price REAL NOT NULL DEFAULT 0,
          min_quantity INTEGER NOT NULL DEFAULT 1
        )''');
        await db.execute('''CREATE TABLE stock_movements (
          id TEXT PRIMARY KEY, center_id TEXT NOT NULL, part_id TEXT NOT NULL,
          movement_type TEXT NOT NULL, quantity INTEGER NOT NULL,
          unit_price REAL NOT NULL DEFAULT 0, note TEXT, created_at TEXT NOT NULL
        )''');
        await db.execute('''CREATE TABLE transactions (
          id TEXT PRIMARY KEY, center_id TEXT NOT NULL, type TEXT NOT NULL,
          amount REAL NOT NULL, note TEXT, created_at TEXT NOT NULL
        )''');
      },
    );
    return _db!;
  }

  Future<Map<String, Object?>> createCenter({required String centerName, required String ownerName, required String username, required String password}) async {
    final db = await database;
    final centerId = newId();
    final userId = newId();
    final now = DateTime.now().toIso8601String();
    await db.transaction((txn) async {
      await txn.insert('centers', {
        'id': centerId, 'name': centerName, 'owner_name': ownerName,
        'username': username, 'password_hash': hashPassword(password), 'created_at': now,
      });
      await txn.insert('users', {
        'id': userId, 'center_id': centerId, 'name': ownerName,
        'username': username, 'password_hash': hashPassword(password), 'role': 'owner', 'active': 1,
      });
    });
    return {'center_id': centerId, 'user_id': userId, 'center_name': centerName, 'user_name': ownerName, 'role': 'owner'};
  }

  Future<Map<String, Object?>?> login(String username, String password) async {
    final db = await database;
    final rows = await db.rawQuery('''SELECT users.*, centers.name AS center_name
      FROM users JOIN centers ON centers.id = users.center_id
      WHERE users.username = ? AND users.password_hash = ? AND users.active = 1 LIMIT 1''',
      [username.trim(), hashPassword(password)]);
    if (rows.isEmpty) return null;
    final r = rows.first;
    return {'center_id': r['center_id'], 'user_id': r['id'], 'center_name': r['center_name'], 'user_name': r['name'], 'role': r['role']};
  }

  Future<List<Map<String, Object?>>> devices(String centerId, {String query = ''}) async {
    final db = await database;
    if (query.trim().isEmpty) return db.query('devices', where: 'center_id = ?', whereArgs: [centerId], orderBy: 'created_at DESC');
    return db.query('devices', where: 'center_id = ? AND (serial LIKE ? OR model LIKE ? OR customer_name LIKE ?)', whereArgs: [centerId, '%$query%', '%$query%', '%$query%'], orderBy: 'created_at DESC');
  }

  Future<void> addDevice(String centerId, Map<String, Object?> data) async {
    final db = await database;
    await db.insert('devices', {'id': newId(), 'center_id': centerId, ...data, 'created_at': DateTime.now().toIso8601String()});
  }

  Future<List<Map<String, Object?>>> parts(String centerId) async {
    final db = await database;
    return db.query('parts', where: 'center_id = ?', whereArgs: [centerId], orderBy: 'name COLLATE NOCASE');
  }

  Future<void> addPart(String centerId, {required String name, required String sku, required int quantity, required double purchase, required double sale, required int minQty}) async {
    final db = await database;
    final id = newId();
    await db.transaction((txn) async {
      await txn.insert('parts', {'id': id, 'center_id': centerId, 'name': name, 'sku': sku, 'quantity': quantity, 'purchase_price': purchase, 'sale_price': sale, 'min_quantity': minQty});
      if (quantity > 0) {
        await txn.insert('stock_movements', {'id': newId(), 'center_id': centerId, 'part_id': id, 'movement_type': 'in', 'quantity': quantity, 'unit_price': purchase, 'note': 'Opening stock', 'created_at': DateTime.now().toIso8601String()});
      }
    });
  }

  Future<void> addTransaction(String centerId, {required String type, required double amount, required String note}) async {
    final db = await database;
    await db.insert('transactions', {'id': newId(), 'center_id': centerId, 'type': type, 'amount': amount, 'note': note, 'created_at': DateTime.now().toIso8601String()});
  }

  Future<Map<String, double>> financeSummary(String centerId) async {
    final db = await database;
    final rows = await db.query('transactions', where: 'center_id = ?', whereArgs: [centerId]);
    double income = 0, expense = 0;
    for (final row in rows) {
      final amount = (row['amount'] as num).toDouble();
      if (row['type'] == 'income') income += amount; else expense += amount;
    }
    return {'income': income, 'expense': expense, 'net': income - expense};
  }

  Future<List<Map<String, Object?>>> transactions(String centerId) async {
    final db = await database;
    return db.query('transactions', where: 'center_id = ?', whereArgs: [centerId], orderBy: 'created_at DESC');
  }

  Future<void> addRepair(String centerId, String deviceId, {required String technician, required String diagnosis, required String workDone, required double labor, required double parts, required double received}) async {
    final db = await database;
    await db.insert('repairs', {'id': newId(), 'center_id': centerId, 'device_id': deviceId, 'technician': technician, 'diagnosis': diagnosis, 'work_done': workDone, 'labor_cost': labor, 'parts_cost': parts, 'received_amount': received, 'created_at': DateTime.now().toIso8601String()});
    await db.update('devices', {'status': 'completed'}, where: 'id = ? AND center_id = ?', whereArgs: [deviceId, centerId]);
    final total = labor + parts;
    if (received > 0) await addTransaction(centerId, type: 'income', amount: received, note: 'Repair payment: $deviceId');
  }

  Future<List<Map<String, Object?>>> employees(String centerId) async {
    final db = await database;
    return db.query('users', columns: ['id','name','username','role','active'], where: 'center_id = ?', whereArgs: [centerId], orderBy: 'name');
  }

  Future<void> addEmployee(String centerId, {required String name, required String username, required String password, required String role}) async {
    final db = await database;
    await db.insert('users', {'id': newId(), 'center_id': centerId, 'name': name, 'username': username, 'password_hash': hashPassword(password), 'role': role, 'active': 1});
  }
}
