إعدادات بناء ALBYATE v0.3.2

- Android Gradle Plugin: 8.11.1
- Kotlin Gradle Plugin: 2.1.0 (الإصدار الأصلي للمشروع)
- Gradle Wrapper: 8.14.3
- Java: 17
- android.newDsl=false

ملاحظة: هذه تهيئة متناسقة لتفادي استخدام AGP 9 ونسخة Gradle الأقدم من الحد الذي ظهر في سجل البناء. يجب التحقق من نجاح البناء في GitHub Actions؛ لم يُنفذ بناء Android فعلي داخل هذه البيئة.
