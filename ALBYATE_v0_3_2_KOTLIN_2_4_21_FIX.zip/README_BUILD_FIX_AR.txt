ALBYATE v0.3.2 - Kotlin metadata compatibility update

Root cause from the supplied GitHub Actions log:
Firebase Auth 25.0.0 contains Kotlin metadata 2.4.0, but the project used Kotlin Gradle Plugin 2.2.20.

Change:
- Updated org.jetbrains.kotlin.android from 2.2.20 to 2.4.21.
- Removed the module-local Firebase Auth 23.2.1 force override. It did not solve the reported compiler metadata mismatch and could constrain Firebase dependency alignment.
- Kept Android Gradle Plugin 8.11.1 and Gradle 8.14. Their compatibility is supported by Kotlin Gradle Plugin 2.4.21.
- Updated the GitHub Actions workflow to build from the checked-out project and upload the APK only after a successful build.

Upload the CONTENTS of this ZIP to the repository root (merge/replace files), then run:
Build ALBYATE APK - Kotlin 2.4.21

This is a source/build-fix package, not a prebuilt APK. A successful APK still requires a real GitHub Actions run.
